# ExaQuizApp

React Native app with Signup Screen.

## How to Run

```bash
npm install
npx react-native run-android
```