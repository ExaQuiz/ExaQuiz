import React from 'react';
import SignupScreen from './components/SignupScreen';

export default function App() {
  return <SignupScreen />;
}